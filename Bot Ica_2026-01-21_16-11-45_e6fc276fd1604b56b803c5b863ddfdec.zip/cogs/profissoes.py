# Fixed profissoes.py (With requested changes and fixes for database, removed pass in error handlers to show errors, added specialization column)

import discord
from discord.ext import commands
from datetime import datetime, timedelta
import random

class Profissoes(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.setup_tables()
        
        self.PROFISSOES = {
            'cacador': {
                'nome': 'Cacador',
                'emoji': '🏹',
                'descricao': 'Especialista em caca e coleta de recursos',
                'comandos': ['cacar', 'rastrear', 'armar'],
                'recursos': ['Pele de Lobo', 'Carne Fresca', 'Osso Animal', 'Presa de Javali', 'Pena de Aguia'],
                'especializacoes': ['Arqueiro', 'Rastreador', 'Caçador de Elite'],
                'ferramentas': ['Arco', 'Armadilha', 'Faca de Caça'],
                'cooperativa': True,
                'secreta': False
            },
            'engenheiro': {
                'nome': 'Engenheiro',
                'emoji': '⚙️',
                'descricao': 'Especialista em fabricar e construir itens',
                'comandos': ['construir', 'reparar', 'projetar'],
                'recursos': ['Engrenagem', 'Parafuso', 'Circuito', 'Motor', 'Maquina'],
                'especializacoes': ['Mecânico', 'Eletricista', 'Arquiteto'],
                'ferramentas': ['Chave de Fenda', 'Multímetro', 'Planta'],
                'cooperativa': True,
                'secreta': False
            },
            'alquimista': {
                'nome': 'Alquimista',
                'emoji': '⚗️',
                'descricao': 'Especialista em pocoes e transmutacoes',
                'comandos': ['sintetizar', 'transmutar', 'destilar'],
                'recursos': ['Pocao de Vida', 'Elixir de Forca', 'Essencia Magica', 'Pedra Filosofal', 'Extracto Raro'],
                'especializacoes': ['Poções', 'Transmutação', 'Alquimia Avançada'],
                'ferramentas': ['Frasco', 'Morteiro', 'Destilador'],
                'cooperativa': False,
                'secreta': False
            },
            'chef': {
                'nome': 'Chef',
                'emoji': '👨‍🍳',
                'descricao': 'Especialista em culinaria e gastronomia',
                'comandos': ['cozinhar', 'preparar', 'assar'],
                'recursos': ['Prato Gourmet', 'Sobremesa Fina', 'Sopa Especial', 'Banquete Real', 'Doce Raro'],
                'especializacoes': ['Cozinheiro', 'Padeiro', 'Chef Estrela'],
                'ferramentas': ['Faca de Chef', 'Forno', 'Panela'],
                'cooperativa': True,
                'secreta': False
            },
            'comerciante': {
                'nome': 'Comerciante',
                'emoji': '💼',
                'descricao': 'Especialista em negocios e comercio',
                'comandos': ['negociar', 'investir', 'especular'],
                'recursos': ['Contrato Lucrativo', 'Acordo Comercial', 'Investimento', 'Lucro Extra', 'Monopolio'],
                'especializacoes': ['Negociador', 'Investidor', 'Mercador'],
                'ferramentas': ['Contrato', 'Bolsa', 'Calculadora'],
                'cooperativa': True,
                'secreta': False
            },
            # New: Illegal/Secret professions
            'ladrao': {
                'nome': 'Ladrao',
                'emoji': '🕵️',
                'descricao': 'Especialista em furtos e infiltracao (secreta)',
                'comandos': ['assaltar', 'infiltrar', 'arrombar'],
                'recursos': ['Joia Roubada', 'Dinheiro Sujo', 'Artefato Antigo'],
                'especializacoes': ['Ladrão de Elite', 'Espião', 'Arrombador'],
                'ferramentas': ['Ganzua', 'Capuz', 'Luvas'],
                'cooperativa': False,
                'secreta': True
            },
            'assassino': {
                'nome': 'Assassino',
                'emoji': '🔪',
                'descricao': 'Especialista em eliminacoes silenciosas (secreta)',
                'comandos': ['eliminar', 'emboscar', 'envenenar'],
                'recursos': ['Veneno', 'Adaga', 'Contrato de Assassinato'],
                'especializacoes': ['Matador', 'Envenenador', 'Sniper'],
                'ferramentas': ['Adaga', 'Veneno', 'Arco Silencioso'],
                'cooperativa': False,
                'secreta': True
            }
        }
    
    def setup_tables(self):
        conn = self.bot.db.get_connection()
        cursor = conn.cursor()
        
        # Add specialization column if not exists (SQLite doesn't support IF NOT EXISTS for columns, so use try-except)
        try:
            cursor.execute("ALTER TABLE profissao_progresso ADD COLUMN specialization TEXT")
            conn.commit()
        except:
            pass  # Column already exists
        
        conn.close()
    
    @commands.command(name='profissoes', aliases=['profissao', 'jobs'])
    async def profissoes(self, ctx):
        """Ver todas as profissoes disponiveis"""
        embed = discord.Embed(
            title="Sistema de Profissoes",
            description="Escolha uma profissao para comecar sua jornada! Profissoes secretas sao desbloqueadas via missoes.",
            color=discord.Color.gold()
        )
        
        for key, prof in self.PROFISSOES.items():
            if prof['secreta']:
                continue  # Hide secret ones
            comandos_text = ", ".join([f"`!{cmd}`" for cmd in prof['comandos']])
            embed.add_field(
                name=f"{prof['emoji']} {prof['nome']}",
                value=f"{prof['descricao']}\n**Comandos:** {comandos_text}",
                inline=False
            )
        
        embed.set_footer(text="Use !escolher <profissao> para escolher")
        
        await ctx.send(embed=embed)
    
    @commands.command(name='escolher', aliases=['choose'])
    async def escolher(self, ctx, profissao: str = None):
        """Escolher uma profissao"""
        if profissao is None:
            await ctx.send("Especifique a profissao! Use `!profissoes` para ver a lista.")
            return
        
        profissao = profissao.lower()
        
        if profissao not in self.PROFISSOES:
            await ctx.send(f"Profissao invalida! Use: {', '.join([k for k,v in self.PROFISSOES.items() if not v['secreta']])}")
            return
        
        if self.PROFISSOES[profissao]['secreta']:
            # Check if unlocked (assume a conquest check)
            user_id = str(ctx.author.id)
            conn = self.bot.db.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM conquistas_usuario WHERE user_id = ? AND achievement_id = ?",
                           (user_id, f"unlock_{profissao}"))  # Example achievement ID
            if not cursor.fetchone():
                await ctx.send("Esta profissao e secreta e nao foi desbloqueada!")
                conn.close()
                return
            conn.close()
        
        user_id = str(ctx.author.id)
        self.bot.db.ensure_user_exists(user_id)
        
        conn = self.bot.db.get_connection()
        cursor = conn.cursor()
        
        prof_name = self.PROFISSOES[profissao]['nome']
        
        cursor.execute("""
            INSERT OR IGNORE INTO profissoes (name, description, icon) VALUES (?, ?, ?)
        """, (prof_name, 
              self.PROFISSOES[profissao]['descricao'],
              self.PROFISSOES[profissao]['emoji']))
        conn.commit()
        
        cursor.execute("SELECT profession_id FROM profissoes WHERE name = ?", (prof_name,))
        prof_data = cursor.fetchone()
        profession_id = prof_data['profession_id']
        
        cursor.execute("""
            SELECT * FROM profissao_progresso WHERE user_id = ? AND profession_id = ?
        """, (user_id, profession_id))
        
        existing = cursor.fetchone()
        
        if existing:
            await ctx.send(f"Voce ja escolheu esta profissao! Nivel atual: {existing['level']}")
            conn.close()
            return
        
        cursor.execute("""
            INSERT INTO profissao_progresso (user_id, profession_id, chosen_at)
            VALUES (?, ?, ?)
        """, (user_id, profession_id, datetime.now().isoformat()))
        
        conn.commit()
        conn.close()
        
        prof = self.PROFISSOES[profissao]
        
        embed = discord.Embed(
            title=f"{prof['emoji']} Profissao Escolhida!",
            description=f"Voce agora e um(a) **{prof['nome']}**!\n\n{prof['descricao']}",
            color=discord.Color.green()
        )
        
        embed.add_field(
            name="Comandos Disponiveis",
            value="\n".join([f"`!{cmd}`" for cmd in prof['comandos']]),
            inline=False
        )
        
        embed.add_field(
            name="Especializacoes",
            value="\n".join(prof['especializacoes']),
            inline=True
        )
        
        embed.add_field(
            name="Ferramentas Exclusivas",
            value="\n".join(prof['ferramentas']),
            inline=True
        )
        
        await ctx.send(embed=embed)
    
    @commands.command(name='minhaprofissao', aliases=['myprofession'])
    async def minhaprofissao(self, ctx):
        """Ver sua profissao atual"""
        user_id = str(ctx.author.id)
        
        conn = self.bot.db.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT p.name, p.icon, pp.level, pp.xp, pp.chosen_at, pp.specialization
            FROM profissao_progresso pp
            JOIN profissoes p ON pp.profession_id = p.profession_id
            WHERE pp.user_id = ?
            ORDER BY pp.level DESC
        """, (user_id,))
        
        professions = cursor.fetchall()
        conn.close()
        
        if not professions:
            await ctx.send("Voce ainda nao escolheu nenhuma profissao! Use `!profissoes` para ver as opcoes.")
            return
        
        embed = discord.Embed(
            title=f"Profissoes de {ctx.author.display_name}",
            color=discord.Color.gold()
        )
        
        for prof in professions:
            xp_needed = prof['level'] * 100
            progress = min(prof['xp'] / xp_needed * 100, 100) if xp_needed > 0 else 0
            
            embed.add_field(
                name=f"{prof['icon']} {prof['name']}",
                value=f"Nivel: **{prof['level']}**\nXP: **{prof['xp']}** / {xp_needed}\nProgresso: {progress:.1f}%\nEspecializacao: {prof['specialization'] or 'Nenhuma'}",
                inline=True
            )
        
        await ctx.send(embed=embed)
    
    @commands.command(name='especializar', aliases=['specialize'])
    async def especializar(self, ctx, profissao: str, especializacao: str):
        """Escolher uma especializacao dentro da profissao"""
        profissao = profissao.lower()
        if profissao not in self.PROFISSOES:
            await ctx.send("Profissao invalida!")
            return
        
        prof = self.PROFISSOES[profissao]
        if especializacao not in prof['especializacoes']:
            await ctx.send(f"Especializacao invalida! Opcoes: {', '.join(prof['especializacoes'])}")
            return
        
        user_id = str(ctx.author.id)
        conn = self.bot.db.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT profession_id FROM profissoes WHERE LOWER(name) = ?", (prof['nome'].lower(),))
        prof_id = cursor.fetchone()['profession_id']
        
        cursor.execute("UPDATE profissao_progresso SET specialization = ? WHERE user_id = ? AND profession_id = ?",
                       (especializacao, user_id, prof_id))
        
        conn.commit()
        conn.close()
        
        await ctx.send(f"Especializacao '{especializacao}' equipada para {prof['nome']}!")

    async def profession_action(self, ctx, profession_key: str, action_name: str, cooldown_seconds: int):
        """Funcao generica para acoes de profissao com falhas aleatorias"""
        user_id = str(ctx.author.id)
        prof = self.PROFISSOES[profession_key]
        
        conn = self.bot.db.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT profession_id FROM profissoes WHERE LOWER(name) = ?", (prof['nome'].lower(),))
        prof_data = cursor.fetchone()
        
        if not prof_data:
            await ctx.send(f"Voce precisa escolher a profissao {prof['nome']} primeiro! Use `!escolher {profession_key}`")
            conn.close()
            return False
        
        cursor.execute("""
            SELECT * FROM profissao_progresso 
            WHERE user_id = ? AND profession_id = ?
        """, (user_id, prof_data['profession_id']))
        
        progress = cursor.fetchone()
        
        if not progress:
            await ctx.send(f"Voce precisa escolher a profissao {prof['nome']} primeiro! Use `!escolher {profession_key}`")
            conn.close()
            return False
        
        level = progress['level']
        xp = progress['xp']
        
        # Random failure (10% chance)
        if random.random() < 0.1:
            failure_msg = random.choice(["Falha critica! Voce perdeu recursos.", "Algo deu errado... Sem recompensas."])
            await ctx.send(f"❌ {failure_msg}")
            conn.close()
            return True  # Still count as action
        
        xp_gain = random.randint(10, 25) + (level * 2)
        coins_gain = random.randint(50, 150) * level
        
        new_xp = xp + xp_gain
        new_level = level
        
        xp_needed = level * 100
        if new_xp >= xp_needed:
            new_level += 1
            new_xp = new_xp - xp_needed
        
        cursor.execute("""
            UPDATE profissao_progresso 
            SET xp = ?, level = ?
            WHERE user_id = ? AND profession_id = ?
        """, (new_xp, new_level, user_id, prof_data['profession_id']))
        
        cursor.execute("""
            UPDATE economia 
            SET coins = coins + ?, total_earned = total_earned + ?
            WHERE user_id = ?
        """, (coins_gain, coins_gain, user_id))
        
        resource = random.choice(prof['recursos'])
        
        cursor.execute("""
            SELECT * FROM inventario 
            WHERE user_id = ? AND item_name = ?
        """, (user_id, resource))
        
        existing_item = cursor.fetchone()
        
        if existing_item:
            cursor.execute("""
                UPDATE inventario 
                SET quantity = quantity + 1
                WHERE inventory_id = ?
            """, (existing_item['inventory_id'],))
        else:
            cursor.execute("""
                INSERT INTO inventario (user_id, item_name, item_type, quantity, rarity, description)
                VALUES (?, ?, 'material', 1, 'comum', ?)
            """, (user_id, resource, f"Material obtido como {prof['nome']}"))
        
        conn.commit()
        conn.close()
        
        embed = discord.Embed(
            title=f"{prof['emoji']} {action_name}!",
            color=discord.Color.green()
        )
        
        embed.add_field(
            name="Recompensas",
            value=f"Moedas: **+{coins_gain:,}**\nXP: **+{xp_gain}**\nItem: **{resource}**",
            inline=True
        )
        
        embed.add_field(
            name="Progresso",
            value=f"Nivel: **{new_level}**\nXP: **{new_xp}** / {new_level * 100}",
            inline=True
        )
        
        if new_level > level:
            embed.add_field(
                name="Subiu de nivel!",
                value=f"Nivel {level} → **Nivel {new_level}**",
                inline=False
            )
        
        await ctx.send(embed=embed)
        return True
    
    @commands.command(name='cacar', aliases=['hunt'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def cacar(self, ctx):
        """Ir cacar (Cacador)"""
        result = await self.profession_action(ctx, 'cacador', 'Caca Realizada', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @cacar.error
    async def cacar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='rastrear', aliases=['track'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def rastrear(self, ctx):
        """Rastrear presas (Cacador)"""
        result = await self.profession_action(ctx, 'cacador', 'Rastreamento Concluido', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @rastrear.error
    async def rastrear_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='armar', aliases=['trap'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def armar(self, ctx):
        """Armar armadilhas (Cacador)"""
        result = await self.profession_action(ctx, 'cacador', 'Armadilha Armada', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @armar.error
    async def armar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='construir', aliases=['build'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def construir(self, ctx):
        """Construir algo (Engenheiro)"""
        result = await self.profession_action(ctx, 'engenheiro', 'Construcao Concluida', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @construir.error
    async def construir_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='reparar', aliases=['repair'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def reparar(self, ctx):
        """Reparar algo (Engenheiro)"""
        result = await self.profession_action(ctx, 'engenheiro', 'Reparo Concluido', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @reparar.error
    async def reparar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='projetar', aliases=['design'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def projetar(self, ctx):
        """Projetar algo (Engenheiro)"""
        result = await self.profession_action(ctx, 'engenheiro', 'Projeto Concluido', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @projetar.error
    async def projetar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='sintetizar', aliases=['synthesize'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def sintetizar(self, ctx):
        """Sintetizar pocoes (Alquimista)"""
        result = await self.profession_action(ctx, 'alquimista', 'Sintese Concluida', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @sintetizar.error
    async def sintetizar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='transmutar', aliases=['transmute'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def transmutar(self, ctx):
        """Transmutar materiais (Alquimista)"""
        result = await self.profession_action(ctx, 'alquimista', 'Transmutacao Concluida', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @transmutar.error
    async def transmutar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='destilar', aliases=['distill'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def destilar(self, ctx):
        """Destilar essencias (Alquimista)"""
        result = await self.profession_action(ctx, 'alquimista', 'Destilacao Concluida', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @destilar.error
    async def destilar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='cozinhar', aliases=['cook'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def cozinhar(self, ctx):
        """Cozinhar um prato (Chef)"""
        result = await self.profession_action(ctx, 'chef', 'Prato Preparado', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @cozinhar.error
    async def cozinhar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='preparar', aliases=['prepare'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def preparar(self, ctx):
        """Preparar ingredientes (Chef)"""
        result = await self.profession_action(ctx, 'chef', 'Preparacao Concluida', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @preparar.error
    async def preparar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='assar', aliases=['bake'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def assar(self, ctx):
        """Assar algo (Chef)"""
        result = await self.profession_action(ctx, 'chef', 'Assado Concluido', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @assar.error
    async def assar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='negociar', aliases=['negotiate'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def negociar(self, ctx):
        """Negociar contratos (Comerciante)"""
        result = await self.profession_action(ctx, 'comerciante', 'Negociacao Concluida', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @negociar.error
    async def negociar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='investir', aliases=['invest'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def investir(self, ctx):
        """Fazer investimentos (Comerciante)"""
        result = await self.profession_action(ctx, 'comerciante', 'Investimento Realizado', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @investir.error
    async def investir_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    @commands.command(name='especular', aliases=['speculate'])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def especular(self, ctx):
        """Especular no mercado (Comerciante)"""
        result = await self.profession_action(ctx, 'comerciante', 'Especulacao Concluida', 1800)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @especular.error
    async def especular_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    # Secret profession commands (example for ladrao)
    @commands.command(name='assaltar', aliases=['assault'])
    @commands.cooldown(1, 3600, commands.BucketType.user)
    async def assaltar(self, ctx):
        """Assaltar algo (Ladrao)"""
        result = await self.profession_action(ctx, 'ladrao', 'Assalto Realizado', 3600)
        if not result:
            ctx.command.reset_cooldown(ctx)
    
    @assaltar.error
    async def assaltar_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Comando em cooldown! Espere {error.retry_after:.0f} segundos.")
        else:
            await ctx.send(f"Erro: {error}")
    
    # Add similar for infiltrar, arrombar, eliminar, emboscar, envenenar if needed

async def setup(bot):
    await bot.add_cog(Profissoes(bot))